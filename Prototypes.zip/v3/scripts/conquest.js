var gameElement;
var gameCanvas
var playerName;
var UIElement;
var playerNameElement;
var playerScoreElement;
var playerCoinsElement;
var playerTilesElement;
var playerMinesElement;
var playerColor;
var ctx;
var score;
var tiles;
var coins;
var mines;
var grd;
var gameTickMili;

// this 'local' refers to the local unit of how many blocks are on the x and y axis. Changing these values will influence map size.
const mapXlocal=30;
const mapYlocal=30;
var mapData = new Array(mapXlocal);

for (var i = 0; i < mapData.length; i++) {
  mapData[i] = new Array(mapYlocal);
}

function start()
{  
	gameTickMili = 10000;
	gameElement = document.getElementById("gamePanel");
	gameElement.innerHTML = "<center>Username<br><input type='text' id='usernameInput'></input><br><br> <button href ='#' class='joinButton' type='button' onclick='joinGame()'>Join Game</button></center>";
}  
function joinGame()
{
	if(document.getElementById("usernameInput").value!==""&&document.getElementById("usernameInput").value!=null&&document.getElementById("usernameInput").value.includes(' ')!=true&&document.getElementById("usernameInput").value.includes('<')!=true&&document.getElementById("usernameInput").value.includes('>')!=true&&document.getElementById("usernameInput").value.includes('$')!=true)
	{
	playerName = document.getElementById("usernameInput").value;
	gameElement.innerHTML = "<p>Game internally initialized! Everything looks good. The map should now generate and replace this.</p>";
	playerColor = "#"+Math.floor(Math.random()*16777215).toString(16);
	score = 0;
	mines = 0;
	coins = 10;
	tiles = 1;
	setInterval(doGameTick, gameTickMili);
	//gameElement.style.backgroundColor = playerColor;
	instantiateMap();
	}
	else if(document.getElementById("usernameInput").value==null)
	{
		alert("You can't use spaces in your name!");
	}
	else if(document.getElementById("usernameInput").value=="")
	{
		alert("You forgot to enter a username fucking retard");
	}
	else if(document.getElementById("usernameInput").value.includes(' ')==true)
	{
		alert("You cant put spaces in your name!");
	}
	else
	{
		alert("Please use a-z and 1-9 in your username only!");
	}
}
function instantiateMap()
{
	gameElement.innerHTML = "<div class='lineSort'><div class='overlay align' id='overlay'><p id='playerNameUI' class='bold'></p><p id='playerScoreUI'></p><p id='playerCoinsUI'></p><p id='playerTilesUI'></p><p id='playerMinesUI'></p></div><div position: absolute class='draggable align'id='draggable'><canvas id='gamespace' class='gamespace' width='1510' height='1510'></canvas></div></div>";
	playerNameElement = document.getElementById("playerNameUI");
	playerNameElement.innerHTML = playerName;
	playerScoreElement = document.getElementById("playerScoreUI");
	playerScoreElement.innerHTML = "Score: "+score;
	playerCoinsElement = document.getElementById("playerCoinsUI");
	playerCoinsElement.innerHTML = "Coins: "+coins;
	playerTilesElement = document.getElementById("playerTilesUI");
	playerTilesElement.innerHTML = "Tiles: "+tiles;
	playerMinesElement = document.getElementById("playerMinesUI");
	playerMinesElement.innerHTML = "Mines: "+mines;
	UIElement = document.getElementById("overlay");
	UIElement.style.color = playerColor;
	gameCanvas = document.getElementById('gamespace');
	ctx = gameCanvas.getContext('2d');
	canvas = document.querySelector('canvas')
	enableCanvasListener();
	createRect();
	defineAI();
}
function createRect()
{
	
	for(let gY = 0;mapYlocal>gY;gY++)
	{
		for(let gX = 0;mapXlocal>gX;gX++)
		{
			grd = ctx.createLinearGradient((50*gX)+10, (50*gY)+10, (50*gX)+60, (50*gY)+10);
			grd.addColorStop(0, "#feebbc");
			grd.addColorStop(.5, "#e9d2ba");
			grd.addColorStop(1, "#f9d9b6");
			ctx.fillStyle = '#828282';
			ctx.fillRect((50*gX)+10, 50*(gY)+10, 50, 50);
			ctx.fillStyle = grd;
			ctx.fillRect((50*gX)+11, 50*(gY)+11, 48, 48);
		}
	}
	var r=Math.round(Math.random()*200);
	var g=Math.round(Math.random()*200);
	var b=Math.round(Math.random()*200);
	var randomLocX = getRandomInt(mapXlocal-1);
	var randomLocY = getRandomInt(mapYlocal-1);
	mapData[randomLocX][randomLocY]=playerName;
	ctx.fillStyle = '#000000';
	ctx.fillRect(10+(50*randomLocX), 10+(50*randomLocY), 50, 50);
	ctx.fillStyle = playerColor;
    ctx.fillRect(11+(50*randomLocX), 11+(50*randomLocY), 48, 48);
}
var max;
function getRandomInt(max) 
{
  return Math.floor(Math.random() * max);
}



function getCursorPosition(canvas, event) {
    const rect = canvas.getBoundingClientRect()
    const x = event.clientX - rect.left
    const y = event.clientY - rect.top
    console.log("x: " + x + " y: " + y)
	computeClick(x,y)
}

var canvas = document.querySelector('canvas')
function enableCanvasListener()
{
	canvas.addEventListener('mousedown', function(e) {
		getCursorPosition(canvas, e)
	})
}



function computeClick(xLoc, yLoc)
{
	var squareLocalX = Math.ceil((xLoc-10)/50)
	var squareLocalY = Math.ceil((yLoc-10)/50);
	console.log("squareLocalX: " + squareLocalX + " squardLocalY: " + squareLocalY)
	if(coins>=1&&mapData[squareLocalX-1][squareLocalY-1]!=playerName)
	{
		if(mapData[squareLocalX][squareLocalY-1]==playerName||mapData[squareLocalX-1][squareLocalY]==playerName||mapData[squareLocalX-2][squareLocalY-1]==playerName||mapData[squareLocalX-1][squareLocalY-2]==playerName)
		{
			coins--;
			tiles++;
			score++;
			setTimeout(claimTile(squareLocalX,squareLocalY),50000);
			refreshOverlay();
		}
	}
	else if(coins>=5&&mapData[squareLocalX-1][squareLocalY-1]==playerName)
	{
		coins=coins-5;
		score++;
		setTimeout(buildMine(squareLocalX,squareLocalY),50000);
		refreshOverlay();
	}
}
function claimTile(tileX,tileY)
{
	var actualX = (tileX*50)-40
	var actualY = (tileY*50)-40
	ctx.fillStyle = '#000000';
	ctx.fillRect(actualX, actualY, 50, 50);
	ctx.fillStyle = playerColor;
    ctx.fillRect(1+actualX, 1+actualY, 48, 48);
	mapData[tileX-1][tileY-1]=playerName;
}
function buildMine(tileX,tileY)
{
	var actualX = (tileX*50)-40
	var actualY = (tileY*50)-40
	ctx.beginPath();
	ctx.arc(actualX+25, actualY+25, 20 , 0, 2 * Math.PI);
	ctx.stroke();
	ctx.fillStyle = "red";
	ctx.fill();
	mines++;
}
function refreshOverlay()
{
	//UIElement.innerHTML = "<p id='playerNameUI' class='bold'></p><p id='playerScoreUI'></p><p id='playerCoinsUI'></p><p id='playerTilesUI'></p>";
	playerNameElement.innerHTML = playerName;
	playerScoreElement.innerHTML = "Score: "+score;
	playerCoinsElement.innerHTML = "Coins: "+coins;
	playerTilesElement.innerHTML = "Tiles: "+tiles;
	playerTilesElement.innerHTML = "Mines: "+mines;
}
function doGameTick()
{
	coins=Math.ceil(coins+(tiles/10)+(mines*2));
	AICoins=AICoins+Math.ceil(AITiles/10);
	refreshOverlay();
}






//AI Code
var AIName;
var AIColor;
var AIOriginX;
var AIOriginY;
var AICoins;
var AITiles;
function defineAI()
{
	AIColor = "#"+Math.floor(Math.random()*16777215).toString(16);
	AIName = "bot";
	var randomLocX = getRandomInt(mapXlocal-1);
	var randomLocY = getRandomInt(mapYlocal-1);
	AIOriginX = randomLocX;
	AIOriginY = randomLocY;
	mapData[randomLocX][randomLocY]=AIName;
	ctx.fillStyle = '#000000';
	ctx.fillRect(10+(50*randomLocX), 10+(50*randomLocY), 50, 50);
	ctx.fillStyle = AIColor;
    ctx.fillRect(11+(50*randomLocX), 11+(50*randomLocY), 48, 48);
	setInterval(AIMove, gameTickMili/10);
	AICoins=10;
	AITiles=1;
}
var attemptX;
var attemptY;
var direction;
function AIMove()
{
	var moved = false;
	//1 up, 2 down, 3 left, 4 right
	attemptX = AIOriginX;
	attemptY = AIOriginY;
	while(!moved)
	{
		direction = getRandomInt(5);
		if(direction==1)
		{
			attemptY++;
		}
		if(direction==2)
		{
			attemptY--;
		}
		if(direction==3)
		{
			attemptX--;
		}
		if(direction==4)
		{
			attemptX++;
		}
		if(!moved)
		{
			if(mapData[attemptX-1][attemptY-1]==AIName)
			{
				moved=false;
			}
			else
			{
				if(AICoins>=1)
				{
					console.log(direction);
					mapData[attemptX-1][attemptY-1]=AIName;
					ctx.fillStyle = '#000000';
					ctx.fillRect(10+(50*attemptX), 10+(50*attemptY), 50, 50);
					ctx.fillStyle = AIColor;
					ctx.fillRect(11+(50*attemptX), 11+(50*attemptY), 48, 48);
					AICoins--;
					AITiles++;
				}
				moved=true;
			}
		}
	}
}